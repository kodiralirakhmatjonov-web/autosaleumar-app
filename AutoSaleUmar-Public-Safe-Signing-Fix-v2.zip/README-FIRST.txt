Auto Sale Umar public-repository signing fix v2

This workflow restores a public-safe prepare-signing task.
It generates a NEW Auto Sale Umar-specific private key transiently on the GitHub macOS runner,
encrypts it with IOS_SIGNING_KEY_PASSWORD, deletes the plaintext key, and uploads only:
- distribution-private-key.enc
- autosaleumar-app.certSigningRequest
- NEXT-STEPS.txt
Artifact retention is 1 day.

Manual step: replace .github/workflows/apply-mobile-update.yml with the supplied file and commit to main.
Then Actions -> Auto Sale Umar Native iOS CI -> Run workflow -> prepare-signing.
