# Auto Sale Umar — GitHub-only bare React Native iOS workflow

This repository is intentionally **not an Expo project** after this migration.

## Architecture

- React Native 0.83.6, bare Community CLI project.
- React Navigation replaces Expo Router.
- `react-native-webview` replaces Expo DOM for the production Auto Sale Umar web experience.
- GitHub Actions `macos-26` generates the official React Native iOS native template and compiles it with Xcode.
- Debug builds are manually signed with an Apple Distribution certificate + Ad Hoc provisioning profile containing the registered iPhone UDID.
- Metro is plain React Native Metro, hosted on a GitHub Ubuntu runner.
- Cloudflare Quick Tunnel exposes Metro over HTTPS/WebSocket for Fast Refresh. No Expo tunnel is used.
- The debug IPA contains an iOS Settings field named **Metro tunnel URL**. This lets the installed build switch to a new tunnel URL without rebuilding the IPA.

## First migration

1. Upload this archive to the repository root with the exact name `mobile-update.zip`.
2. Commit to `main`.
3. The existing **Apply mobile-update.zip** workflow runs.
4. During its one-time `npm install`, `scripts/bootstrap-bare-react-native.cjs`:
   - removes `app/`, `src/`, `.eas/`, `eas.json`, `expo-env.d.ts`;
   - removes the old Expo browser-preview workflow;
   - installs the new GitHub workflows;
   - removes its own `postinstall` hook.
5. The workflow verifies that no Expo/EAS dependencies remain and runs TypeScript checking.
6. The bot commits the migrated repository back to `main`.

## Apple signing setup without a MacBook

Run **Actions → iOS - Generate signing CSR → Run workflow**.

Download the `autosaleumar-ios-signing-csr` artifact. It contains:

- `apple-distribution.csr`
- `apple-distribution-private-key.pem`
- `IOS_SIGNING_PRIVATE_KEY_BASE64.txt`

In Apple Developer:

1. Confirm an explicit App ID exists for `com.autosaleumar.app`.
2. Register the target iPhone UDID.
3. Create an **Apple Distribution** certificate with `apple-distribution.csr`.
4. Download the Apple `.cer` file.
5. Create an **Ad Hoc** provisioning profile for `com.autosaleumar.app`.
6. Select the new Apple Distribution certificate.
7. Include the registered iPhone.
8. Download the `.mobileprovision` file.

The GitHub build expects these repository Actions secrets:

- `IOS_SIGNING_PRIVATE_KEY_BASE64`
- `IOS_DISTRIBUTION_CERTIFICATE_BASE64`
- `IOS_ADHOC_PROFILE_BASE64`

The first value is already prepared in `IOS_SIGNING_PRIVATE_KEY_BASE64.txt`. The `.cer` and `.mobileprovision` files need to be base64 encoded before pasting them into GitHub Secrets. Do not commit the private key to the repository.

## Build the registered-iPhone Debug IPA

Run **Actions → iOS - Build registered-iPhone Debug IPA**.

Optionally paste the iPhone UDID into `expected_udid`. The build will fail before Xcode compilation if that UDID is missing from the Ad Hoc provisioning profile.

The workflow:

1. installs npm packages;
2. validates that Expo/EAS are absent;
3. creates an official React Native 0.83.6 native project with Community CLI;
4. uses bundle ID `com.autosaleumar.app` and display name `Auto Sale Umar`;
5. patches `AppDelegate.swift` so Debug can load Metro from iOS Settings;
6. installs CocoaPods;
7. imports the Apple certificate into a temporary GitHub macOS keychain;
8. validates the provisioning profile Team ID and bundle ID;
9. builds an Xcode **Debug** archive;
10. verifies the code signature;
11. creates `AutoSaleUmar-Debug.ipa` and uploads it as a GitHub Actions artifact.

The temporary signing keychain disappears with the GitHub runner.

## Hot reload / Fast Refresh from GitHub

Run **Actions → Metro hot reload → Run workflow** and keep the job running.

The log prints a line similar to:

`METRO URL: https://random-name.trycloudflare.com`

On the iPhone:

1. Open **Settings → Apps → Auto Sale Umar**.
2. Open **Metro tunnel URL**.
3. Paste the exact HTTPS tunnel URL.
4. Force-close Auto Sale Umar.
5. Reopen it.

The debug app now obtains its JavaScript bundle from the GitHub-hosted Metro server.

While that Metro workflow remains running, edit `.tsx` / `.ts` / JavaScript files in GitHub and commit them. The runner polls `main`, resets to the new commit, and Metro detects the changed files. React Native Fast Refresh then updates the connected iPhone.

A GitHub-hosted job is not permanent. Start a new Metro workflow when the previous session ends. A new Quick Tunnel has a new URL; paste that new URL in iOS Settings. The IPA itself does **not** need to be rebuilt just because the tunnel URL changed.

## When a new IPA is required

Fast Refresh is for JavaScript/TypeScript/UI logic. Rebuild the IPA after changing native dependencies, CocoaPods, native iOS code, bundle capabilities, signing, or other native configuration.

## Installing the IPA on the iPhone

A GitHub cloud runner has no physical/network device pairing with your iPhone, so Xcode on that runner cannot directly install over USB. The IPA is nevertheless signed for registered-device distribution.

For one-tap iPhone installation it must be exposed through an HTTPS OTA endpoint (`manifest.plist` + IPA URL) or another registered-device distribution host. This is separate from Expo and separate from App Store Connect. Do not expect an `.ipa` downloaded into the iOS Files app to install by itself.

## App Store Connect later

Debug/Fast Refresh does not need App Store Connect. A separate Release/TestFlight workflow should be added only after the registered-device development loop is stable. If App Store Connect API keys are problematic, the release upload can be designed around another Apple-supported authentication path instead of making the debug workflow depend on that API.
