# GitHub-only iOS development

This repository is a bare React Native 0.83.6 application. Expo and EAS are removed.

## Runtime dependencies

Only React Native, `react-native-webview`, and AsyncStorage are used. React Navigation is intentionally not used so the migration and CI dependency tree stay small and deterministic.

## GitHub Actions

- `Apply mobile-update.zip`: applies ZIP updates and runs a strict npm install + TypeScript check before committing.
- `Bare React Native check`: runs `npm ci`, validates the installed top-level tree, checks for Expo/EAS leftovers, and runs TypeScript.
- `iOS - Generate signing CSR`: creates the private key/CSR needed for Apple signing.
- `iOS - Build registered-iPhone Debug IPA`: uses a GitHub macOS runner/Xcode to generate the native RN iOS template, install Pods, sign, archive and upload the Ad Hoc Debug IPA.
- `Metro hot reload`: runs Metro plus a temporary HTTPS Cloudflare tunnel and watches the selected GitHub branch for commits.

The first migration keeps a one-shot `postinstall` only because the repository's current Apply workflow excludes `.github/` when copying ZIP contents. Once the first migration succeeds, the bootstrap removes that hook from committed `package.json` and installs the new workflows.
