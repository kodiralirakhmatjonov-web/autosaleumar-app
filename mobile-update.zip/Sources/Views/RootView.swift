import SwiftUI

struct RootView: View {
    @EnvironmentObject private var settings: AppSettings
    @EnvironmentObject private var store: AppStore
    @Environment(\.scenePhase) private var scenePhase
    @Environment(\.accessibilityReduceMotion) private var reduceMotion

    @State private var selection: AppTab = .home
    @State private var showsLaunch = true

    var body: some View {
        ZStack {
            TabView(selection: $selection) {
                HomeView(selectTab: { selection = $0 })
                    .tag(AppTab.home)
                    .tabItem { Label(AppTab.home.title(settings.language), systemImage: AppTab.home.symbol) }

                CatalogView()
                    .tag(AppTab.catalog)
                    .tabItem { Label(AppTab.catalog.title(settings.language), systemImage: AppTab.catalog.symbol) }

                FavoritesView()
                    .tag(AppTab.favorites)
                    .tabItem { Label(AppTab.favorites.title(settings.language), systemImage: AppTab.favorites.symbol) }

                MoreView(selectTab: { selection = $0 })
                    .tag(AppTab.more)
                    .tabItem { Label(AppTab.more.title(settings.language), systemImage: AppTab.more.symbol) }
            }
            .tint(.primary)

            if showsLaunch {
                LaunchOverlay {
                    if reduceMotion {
                        showsLaunch = false
                    } else {
                        withAnimation(.easeInOut(duration: ASUDesign.navigationDuration)) {
                            showsLaunch = false
                        }
                    }
                }
                .transition(reduceMotion ? .identity : .opacity)
                .zIndex(100)
            }
        }
        .task { await store.loadIfNeeded() }
        .onChange(of: scenePhase) { _, phase in
            guard phase == .active, !showsLaunch else { return }
            Task { await store.refreshIfStale() }
        }
        .sensoryFeedback(.selection, trigger: selection)
    }
}
