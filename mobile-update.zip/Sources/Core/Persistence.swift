import Foundation

enum Persistence {
    private static let favoritesKey = "ASUFavoriteCarIDs"
    private static let compareKey = "ASUCompareCarIDs"
    private static let legacyCatalogKey = "ASUPublicCatalogCacheV2"
    private static let catalogUpdatedAtKey = "ASUPublicCatalogUpdatedAtV1"
    private static let browserIDKey = "ASUAnonymousBrowserID"
    private static let catalogFileName = "asu-public-catalog-v3.json"

    static func favoriteIDs() -> Set<Int> {
        Set(UserDefaults.standard.array(forKey: favoritesKey) as? [Int] ?? [])
    }

    static func saveFavoriteIDs(_ value: Set<Int>) {
        UserDefaults.standard.set(Array(value).sorted(), forKey: favoritesKey)
    }

    static func compareIDs() -> [Int] {
        Array((UserDefaults.standard.array(forKey: compareKey) as? [Int] ?? []).prefix(3))
    }

    static func saveCompareIDs(_ value: [Int]) {
        UserDefaults.standard.set(Array(value.prefix(3)), forKey: compareKey)
    }

    static func cachedCars() -> [Car] {
        if let url = catalogCacheURL,
           let data = try? Data(contentsOf: url),
           let cars = try? JSONDecoder().decode([Car].self, from: data) {
            return cars
        }

        guard let legacy = UserDefaults.standard.data(forKey: legacyCatalogKey),
              let cars = try? JSONDecoder().decode([Car].self, from: legacy) else {
            return []
        }

        saveCars(cars, updateTimestamp: false)
        UserDefaults.standard.removeObject(forKey: legacyCatalogKey)
        return cars
    }

    static func saveCars(_ cars: [Car], updateTimestamp: Bool = true) {
        guard let data = try? JSONEncoder().encode(cars) else { return }

        if let url = catalogCacheURL {
            try? data.write(to: url, options: .atomic)
        }

        if updateTimestamp {
            let now = Date()
            UserDefaults.standard.set(now.timeIntervalSince1970, forKey: catalogUpdatedAtKey)
        }
    }

    static func catalogUpdatedAt() -> Date? {
        let value = UserDefaults.standard.double(forKey: catalogUpdatedAtKey)
        guard value > 0 else { return nil }
        return Date(timeIntervalSince1970: value)
    }

    static func browserID() -> String {
        if let existing = UserDefaults.standard.string(forKey: browserIDKey), !existing.isEmpty { return existing }
        let value = "asu-ios-\(UUID().uuidString.lowercased())"
        UserDefaults.standard.set(value, forKey: browserIDKey)
        return value
    }

    private static var catalogCacheURL: URL? {
        guard let directory = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first else { return nil }
        return directory.appendingPathComponent(catalogFileName, isDirectory: false)
    }
}
