// Safe CI marker. This file is not imported by the application.
export const WORKFLOW_TEST_MARKER = 'autosaleumar-ci-v2-test-1';
