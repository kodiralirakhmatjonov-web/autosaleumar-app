const fs = require('fs');
const path = require('path');

const root = process.cwd();
const stage = path.join(root, '.reset-root');

function fail(message) {
  console.error(`FULL RESET ERROR: ${message}`);
  process.exit(1);
}
function rm(rel) {
  fs.rmSync(path.join(root, rel), {recursive: true, force: true});
}
function copyDir(source, destination) {
  fs.mkdirSync(destination, {recursive: true});
  for (const entry of fs.readdirSync(source, {withFileTypes: true})) {
    const from = path.join(source, entry.name);
    const to = path.join(destination, entry.name);
    if (entry.isDirectory()) copyDir(from, to);
    else fs.copyFileSync(from, to);
  }
}

if (!fs.existsSync(path.join(stage, 'App.tsx'))) fail('staged clean repository is missing App.tsx');
if (!fs.existsSync(path.join(stage, 'ios', 'AutoSaleUmar.xcodeproj', 'project.pbxproj'))) fail('staged clean repository is missing Xcode project');

// Remove every known file/directory from Expo/EAS and failed migrations.
const obsolete = [
  'app', 'src', 'ios', 'assets', '.eas', '.expo',
  'eas.json', 'expo-env.d.ts', 'EXACT_MIRROR.md',
  'App.tsx', 'app.json', 'babel.config.js', 'metro.config.js', 'tsconfig.json',
  'README.md', '.gitignore'
];
for (const rel of obsolete) rm(rel);

copyDir(stage, root);

// Do NOT touch .github here. Built-in GITHUB_TOKEN does not have the separate
// Workflows repository permission required to rewrite workflow files.
rm('.reset-root');
try { fs.unlinkSync(path.join(root, 'scripts', 'full-reset.cjs')); } catch {}
try { fs.unlinkSync(path.join(root, 'RESET_README.txt')); } catch {}

for (const rel of ['app', '.eas', '.expo', 'eas.json', 'expo-env.d.ts']) {
  if (fs.existsSync(path.join(root, rel))) fail(`obsolete Expo/EAS path survived: ${rel}`);
}
const finalPkg = JSON.parse(fs.readFileSync(path.join(root, 'package.json'), 'utf8'));
const deps = {...(finalPkg.dependencies || {}), ...(finalPkg.devDependencies || {})};
const banned = Object.keys(deps).filter(name => name === 'expo' || name === 'expo-router' || name.startsWith('@expo/') || name.startsWith('expo-'));
if (banned.length) fail(`Expo dependencies survived: ${banned.join(', ')}`);
if (finalPkg.scripts && finalPkg.scripts.postinstall) fail('one-time postinstall survived into final package.json');

console.log('FULL SOURCE RESET COMPLETE: bare React Native source installed; .github intentionally untouched.');
