#!/usr/bin/env bash
set -euo pipefail

BRANCH="${1:-main}"
INTERVAL="${POLL_INTERVAL_SECONDS:-12}"

echo "Watching origin/${BRANCH} every ${INTERVAL}s for JavaScript/TypeScript changes."
while true; do
  sleep "$INTERVAL"
  git fetch --quiet origin "$BRANCH"
  remote_sha="$(git rev-parse "origin/${BRANCH}")"
  local_sha="$(git rev-parse HEAD)"
  if [[ "$remote_sha" == "$local_sha" ]]; then
    continue
  fi

  echo "New commit detected: ${local_sha:0:8} -> ${remote_sha:0:8}"

  if ! git diff --quiet HEAD "origin/${BRANCH}" -- package.json package-lock.json; then
    echo "::warning title=Native/dependency change::package.json or package-lock.json changed. Fast Refresh is intended for JS/TS/UI changes. Restart this workflow after dependencies change; rebuild the IPA for native dependency changes."
  fi

  git reset --hard "origin/${BRANCH}"
  echo "Working tree updated to ${remote_sha}. Metro will detect changed files automatically."
done
