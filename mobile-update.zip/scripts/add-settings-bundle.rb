#!/usr/bin/env ruby
require 'xcodeproj'

project_path = ARGV.fetch(0)
target_name = ARGV.fetch(1, 'AutoSaleUmar')
project = Xcodeproj::Project.open(project_path)
target = project.targets.find { |item| item.name == target_name }
raise "Target #{target_name} not found in #{project_path}" unless target

relative_path = "#{target_name}/Settings.bundle"
file_ref = project.files.find { |item| item.path == relative_path || item.path == 'Settings.bundle' }
file_ref ||= project.main_group.new_reference(relative_path)

unless target.resources_build_phase.files_references.include?(file_ref)
  target.resources_build_phase.add_file_reference(file_ref, true)
end

project.save
puts "Added #{relative_path} to #{target_name} resources"
