const fs = require('fs');

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };

const tsconfig = JSON.parse(fs.readFileSync('tsconfig.json', 'utf8'));
if (!Array.isArray(tsconfig.compilerOptions?.types) || tsconfig.compilerOptions.types.length !== 0) {
  throw new Error('tsconfig.json must explicitly set compilerOptions.types to [] so the React Native base config does not require unused Jest globals.');
}

const forbidden = Object.keys(deps).filter(
  name => name === 'expo' || name === 'expo-router' || name === 'eas-cli' || name.startsWith('expo-') || name.startsWith('@expo/') || name.startsWith('@react-navigation/')
);
if (forbidden.length) {
  throw new Error(`Forbidden framework/navigation dependencies remain: ${forbidden.join(', ')}`);
}

const expected = {
  react: '19.2.0',
  'react-native': '0.83.6',
  'react-native-webview': '13.16.2',
  '@react-native-async-storage/async-storage': '3.1.1',
  '@react-native-community/cli': '20.2.0',
  '@react-native-community/cli-platform-ios': '20.2.0',
  '@react-native/babel-preset': '0.83.6',
  '@react-native/metro-config': '0.83.6',
  '@react-native/typescript-config': '0.83.6',
  '@types/react': '19.2.0',
  typescript: '5.9.2',
};

for (const [name, version] of Object.entries(expected)) {
  if (deps[name] !== version) {
    throw new Error(`${name} must be exactly ${version}; found ${deps[name] ?? 'missing'}`);
  }
}

console.log('Pinned bare React Native dependency manifest OK.');
