const fs = require('fs');

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const deps = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };

function exact(name) {
  const value = deps[name];
  if (!value) throw new Error(`Missing required dependency: ${name}`);
  if (!/^\d+\.\d+\.\d+(?:-[0-9A-Za-z.-]+)?$/.test(value)) {
    throw new Error(`${name} must be pinned to an exact version for deterministic CI; found ${value}`);
  }
  return value;
}

function parts(v) {
  return v.split('-')[0].split('.').map(Number);
}

const rn = exact('react-native');
const navNative = exact('@react-navigation/native');
const bottomTabs = exact('@react-navigation/bottom-tabs');
const nativeStack = exact('@react-navigation/native-stack');
const screens = exact('react-native-screens');
exact('react-native-safe-area-context');
exact('react-native-webview');

const [rnMajor, rnMinor] = parts(rn);
const [navMajor, navMinor, navPatch] = parts(navNative);
const [screensMajor, screensMinor] = parts(screens);

if (rnMajor !== 0 || rnMinor !== 83) {
  throw new Error(`This migration is validated for React Native 0.83.x; found ${rn}`);
}

// @react-navigation/bottom-tabs 7.18.14 declares @react-navigation/native ^7.3.14.
if (navMajor !== 7 || navMinor < 3 || (navMinor === 3 && navPatch < 14)) {
  throw new Error(
    `@react-navigation/native ${navNative} is too old for @react-navigation/bottom-tabs ${bottomTabs}; require >= 7.3.14 < 8`
  );
}

// Native bottom tabs require react-native-screens >=4.25.0. For RN 0.83.x,
// react-native-screens 4.26+ is not supported, so stay on the latest 4.25 patch.
if (screensMajor !== 4 || screensMinor !== 25) {
  throw new Error(
    `React Native ${rn} requires react-native-screens 4.25.x for this native-tabs setup; found ${screens}`
  );
}

if (!bottomTabs.startsWith('7.') || !nativeStack.startsWith('7.')) {
  throw new Error('React Navigation packages must stay on the same stable major version (7.x).');
}

console.log('Compatibility manifest OK:');
console.log(`  react-native: ${rn}`);
console.log(`  @react-navigation/native: ${navNative}`);
console.log(`  @react-navigation/bottom-tabs: ${bottomTabs}`);
console.log(`  @react-navigation/native-stack: ${nativeStack}`);
console.log(`  react-native-screens: ${screens}`);
