#!/usr/bin/env bash
set -euo pipefail

SOURCE_ICON="${1:-assets/icon.png}"
IOS_ROOT="${2:-ios}"

if [[ ! -f "$SOURCE_ICON" ]]; then
  echo "Icon not found: $SOURCE_ICON; keeping template icon assets."
  exit 0
fi

ICONSET="$(find "$IOS_ROOT" -type d -name 'AppIcon.appiconset' -print -quit)"
if [[ -z "$ICONSET" ]]; then
  echo "AppIcon.appiconset not found; skipping icon generation."
  exit 0
fi

rm -f "$ICONSET"/*.png

make_icon() {
  local px="$1"
  local filename="$2"
  sips -s format png -z "$px" "$px" "$SOURCE_ICON" --out "$ICONSET/$filename" >/dev/null
}

make_icon 40 Icon-20@2x.png
make_icon 60 Icon-20@3x.png
make_icon 58 Icon-29@2x.png
make_icon 87 Icon-29@3x.png
make_icon 80 Icon-40@2x.png
make_icon 120 Icon-40@3x.png
make_icon 120 Icon-60@2x.png
make_icon 180 Icon-60@3x.png
make_icon 20 Icon-20@1x-ipad.png
make_icon 40 Icon-20@2x-ipad.png
make_icon 29 Icon-29@1x-ipad.png
make_icon 58 Icon-29@2x-ipad.png
make_icon 40 Icon-40@1x-ipad.png
make_icon 80 Icon-40@2x-ipad.png
make_icon 76 Icon-76@1x.png
make_icon 152 Icon-76@2x.png
make_icon 167 Icon-83.5@2x.png
make_icon 1024 Icon-AppStore-1024.png

cat > "$ICONSET/Contents.json" <<'JSON'
{
  "images": [
    { "idiom": "iphone", "size": "20x20", "scale": "2x", "filename": "Icon-20@2x.png" },
    { "idiom": "iphone", "size": "20x20", "scale": "3x", "filename": "Icon-20@3x.png" },
    { "idiom": "iphone", "size": "29x29", "scale": "2x", "filename": "Icon-29@2x.png" },
    { "idiom": "iphone", "size": "29x29", "scale": "3x", "filename": "Icon-29@3x.png" },
    { "idiom": "iphone", "size": "40x40", "scale": "2x", "filename": "Icon-40@2x.png" },
    { "idiom": "iphone", "size": "40x40", "scale": "3x", "filename": "Icon-40@3x.png" },
    { "idiom": "iphone", "size": "60x60", "scale": "2x", "filename": "Icon-60@2x.png" },
    { "idiom": "iphone", "size": "60x60", "scale": "3x", "filename": "Icon-60@3x.png" },
    { "idiom": "ipad", "size": "20x20", "scale": "1x", "filename": "Icon-20@1x-ipad.png" },
    { "idiom": "ipad", "size": "20x20", "scale": "2x", "filename": "Icon-20@2x-ipad.png" },
    { "idiom": "ipad", "size": "29x29", "scale": "1x", "filename": "Icon-29@1x-ipad.png" },
    { "idiom": "ipad", "size": "29x29", "scale": "2x", "filename": "Icon-29@2x-ipad.png" },
    { "idiom": "ipad", "size": "40x40", "scale": "1x", "filename": "Icon-40@1x-ipad.png" },
    { "idiom": "ipad", "size": "40x40", "scale": "2x", "filename": "Icon-40@2x-ipad.png" },
    { "idiom": "ipad", "size": "76x76", "scale": "1x", "filename": "Icon-76@1x.png" },
    { "idiom": "ipad", "size": "76x76", "scale": "2x", "filename": "Icon-76@2x.png" },
    { "idiom": "ipad", "size": "83.5x83.5", "scale": "2x", "filename": "Icon-83.5@2x.png" },
    { "idiom": "ios-marketing", "size": "1024x1024", "scale": "1x", "filename": "Icon-AppStore-1024.png" }
  ],
  "info": { "version": 1, "author": "xcode" }
}
JSON

echo "Generated iOS app icons in $ICONSET"
