const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

function remove(target) {
  fs.rmSync(path.join(root, target), { recursive: true, force: true });
}

function copyFile(source, target) {
  const from = path.join(root, source);
  const to = path.join(root, target);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
}

if (process.env.GITHUB_ACTIONS !== 'true') {
  console.log('[bare-rn bootstrap] Local npm install: repository migration skipped.');
  process.exit(0);
}

const workflowName = process.env.GITHUB_WORKFLOW || '';
if (!workflowName.includes('Apply mobile-update.zip')) {
  console.log(`[bare-rn bootstrap] Workflow is "${workflowName}"; one-shot migration skipped.`);
  process.exit(0);
}

console.log('[bare-rn bootstrap] Removing Expo/EAS and obsolete navigation source...');
[
  'app',
  'src',
  '.eas',
  '.expo',
  'eas.json',
  'expo-env.d.ts',
  'EXACT_MIRROR.md',
  'mobile/MainTabs.tsx',
  'mobile/navigation.ts',
  'mobile/screens/WebPageScreen.tsx',
  '.github/workflows/deploy-web-preview.yml'
].forEach(remove);

console.log('[bare-rn bootstrap] Installing GitHub-native workflows...');
const workflowDir = path.join(root, 'ci', 'github-workflows');
for (const entry of fs.readdirSync(workflowDir)) {
  if (!entry.endsWith('.yml') && !entry.endsWith('.yaml')) continue;
  copyFile(path.join('ci', 'github-workflows', entry), path.join('.github', 'workflows', entry));
}

console.log('[bare-rn bootstrap] Removing one-shot postinstall hook from committed package.json...');
const packagePath = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
if (pkg.scripts?.postinstall === 'node scripts/bootstrap-bare-react-native.cjs') {
  delete pkg.scripts.postinstall;
}
fs.writeFileSync(packagePath, `${JSON.stringify(pkg, null, 2)}\n`);

console.log('[bare-rn bootstrap] Bare React Native migration complete.');
