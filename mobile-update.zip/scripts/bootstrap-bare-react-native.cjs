const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');

function remove(target) {
  fs.rmSync(path.join(root, target), { recursive: true, force: true });
}

function copyFile(source, target) {
  const from = path.join(root, source);
  const to = path.join(root, target);
  fs.mkdirSync(path.dirname(to), { recursive: true });
  fs.copyFileSync(from, to);
}

// This bootstrap is intentionally one-shot. It only mutates the repository while
// the existing "Apply mobile-update.zip" GitHub workflow is applying this migration.
if (process.env.GITHUB_ACTIONS !== 'true') {
  console.log('[bare-rn bootstrap] Not running in GitHub Actions; skipping repository migration.');
  process.exit(0);
}

const workflowName = process.env.GITHUB_WORKFLOW || '';
if (!workflowName.includes('Apply mobile-update.zip')) {
  console.log(`[bare-rn bootstrap] Workflow is "${workflowName}"; skipping one-shot migration.`);
  process.exit(0);
}

console.log('[bare-rn bootstrap] Removing Expo/EAS application tree...');
[
  'app',
  'src',
  '.eas',
  '.expo',
  'eas.json',
  'expo-env.d.ts',
  '.github/workflows/deploy-web-preview.yml',
  'EXACT_MIRROR.md',
].forEach(remove);

console.log('[bare-rn bootstrap] Installing GitHub-native workflows...');
const workflowDir = path.join(root, 'ci', 'github-workflows');
for (const entry of fs.readdirSync(workflowDir)) {
  if (!entry.endsWith('.yml') && !entry.endsWith('.yaml')) continue;
  copyFile(path.join('ci', 'github-workflows', entry), path.join('.github', 'workflows', entry));
}

console.log('[bare-rn bootstrap] Removing one-shot postinstall hook...');
const packagePath = path.join(root, 'package.json');
const pkg = JSON.parse(fs.readFileSync(packagePath, 'utf8'));
if (pkg.scripts && pkg.scripts.postinstall === 'node scripts/bootstrap-bare-react-native.cjs') {
  delete pkg.scripts.postinstall;
}
fs.writeFileSync(packagePath, `${JSON.stringify(pkg, null, 2)}\n`);

console.log('[bare-rn bootstrap] Expo/EAS migration complete.');
