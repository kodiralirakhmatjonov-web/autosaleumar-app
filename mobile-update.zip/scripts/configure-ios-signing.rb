#!/usr/bin/env ruby
require 'xcodeproj'

project_path = ARGV.fetch(0)
target_name = ARGV.fetch(1)
configuration_name = ARGV.fetch(2)
team_id = ARGV.fetch(3)
profile_name = ARGV.fetch(4)
identity = ARGV.fetch(5, 'Apple Distribution')

project = Xcodeproj::Project.open(project_path)
target = project.targets.find { |item| item.name == target_name }
raise "Target #{target_name} not found in #{project_path}" unless target

configuration = target.build_configurations.find { |item| item.name == configuration_name }
raise "Configuration #{configuration_name} not found for #{target_name}" unless configuration

settings = configuration.build_settings
settings['DEVELOPMENT_TEAM'] = team_id
settings['CODE_SIGN_STYLE'] = 'Manual'
settings['CODE_SIGN_IDENTITY'] = identity
settings['PROVISIONING_PROFILE_SPECIFIER'] = profile_name

project.save
puts "Configured manual signing for #{target_name} / #{configuration_name} with profile #{profile_name}"
