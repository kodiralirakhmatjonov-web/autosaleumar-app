const fs = require('fs');
const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const all = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
const forbidden = Object.keys(all).filter(name => name === 'expo' || name.startsWith('expo-') || name === 'expo-router' || name === 'eas-cli');
if (forbidden.length) {
  console.error(`Expo/EAS dependencies remain: ${forbidden.join(', ')}`);
  process.exit(1);
}
for (const target of ['eas.json', 'expo-env.d.ts', '.eas']) {
  if (fs.existsSync(target)) {
    console.error(`Expo/EAS artifact remains: ${target}`);
    process.exit(1);
  }
}
console.log('Verified: package and repository contain no Expo/EAS runtime configuration.');
