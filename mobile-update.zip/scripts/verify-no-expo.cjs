const fs = require('fs');
const path = require('path');

const pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
const all = { ...(pkg.dependencies || {}), ...(pkg.devDependencies || {}) };
const forbiddenDependencies = Object.keys(all).filter(
  name => name === 'expo' || name === 'expo-router' || name === 'eas-cli' || name.startsWith('expo-') || name.startsWith('@expo/') || name.startsWith('@react-navigation/')
);
if (forbiddenDependencies.length) {
  throw new Error(`Forbidden dependencies remain: ${forbiddenDependencies.join(', ')}`);
}

for (const target of ['eas.json', 'expo-env.d.ts', '.eas', '.expo', 'app']) {
  if (fs.existsSync(target)) {
    throw new Error(`Expo/EAS artifact remains: ${target}`);
  }
}

if (fs.existsSync('package-lock.json')) {
  const lock = JSON.parse(fs.readFileSync('package-lock.json', 'utf8'));
  const keys = Object.keys(lock.packages || {});
  const forbiddenLock = keys.filter(key =>
    /(^|node_modules\/)(expo($|\/|-)|expo-router($|\/)|eas-cli($|\/)|@expo\/|@react-navigation\/)/.test(key)
  );
  if (forbiddenLock.length) {
    throw new Error(`Stale Expo/React Navigation packages remain in package-lock: ${forbiddenLock.slice(0, 12).join(', ')}`);
  }
}

function scan(target) {
  if (!fs.existsSync(target)) return;
  if (fs.statSync(target).isFile()) {
    if (/\.(?:js|jsx|ts|tsx)$/.test(target)) {
      const text = fs.readFileSync(target, 'utf8');
      if (/from\s+['\"](?:expo|expo-|expo-router|@expo\/|@react-navigation\/)|require\(['\"](?:expo|expo-|expo-router|@expo\/|@react-navigation\/)/.test(text)) {
        throw new Error(`Forbidden Expo/React Navigation import remains in ${target}`);
      }
    }
    return;
  }
  for (const entry of fs.readdirSync(target, { withFileTypes: true })) {
    const full = path.join(target, entry.name);
    if (entry.isDirectory()) {
      scan(full);
      continue;
    }
    if (!/\.(?:js|jsx|ts|tsx)$/.test(entry.name)) continue;
    const text = fs.readFileSync(full, 'utf8');
    if (/from\s+['"](?:expo|expo-|expo-router|@expo\/|@react-navigation\/)|require\(['"](?:expo|expo-|expo-router|@expo\/|@react-navigation\/)/.test(text)) {
      throw new Error(`Forbidden Expo/React Navigation import remains in ${full}`);
    }
  }
}
scan('mobile');
scan('App.tsx');

console.log('Verified: runtime source, package manifest and lockfile are free of Expo/EAS/React Navigation.');
