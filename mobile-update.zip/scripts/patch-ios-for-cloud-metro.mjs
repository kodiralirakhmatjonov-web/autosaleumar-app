import fs from 'node:fs';
import path from 'node:path';

const iosRoot = process.argv[2] ? path.resolve(process.argv[2]) : path.resolve('ios');

function walk(dir, predicate) {
  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const full = path.join(dir, entry.name);
    if (entry.isDirectory()) {
      const found = walk(full, predicate);
      if (found) return found;
    } else if (predicate(full)) {
      return full;
    }
  }
  return null;
}

const appDelegate = walk(iosRoot, file => file.endsWith('AppDelegate.swift'));
if (!appDelegate) throw new Error(`AppDelegate.swift not found under ${iosRoot}`);

let swift = fs.readFileSync(appDelegate, 'utf8');
const defaultLine = /(?:return\s+)?RCTBundleURLProvider\.sharedSettings\(\)\.jsBundleURL\(forBundleRoot:\s*"index"\)/;
if (!defaultLine.test(swift)) {
  throw new Error(`Could not find the React Native Metro sourceURL line in ${appDelegate}`);
}

const replacement = `
    if let rawMetroURL = UserDefaults.standard.string(forKey: "metro_url")?.trimmingCharacters(in: .whitespacesAndNewlines),
       !rawMetroURL.isEmpty {
      var normalized = rawMetroURL
      while normalized.hasSuffix("/") { normalized.removeLast() }
      if var components = URLComponents(string: normalized + "/index.bundle") {
        components.queryItems = [
          URLQueryItem(name: "platform", value: "ios"),
          URLQueryItem(name: "dev", value: "true"),
          URLQueryItem(name: "minify", value: "false")
        ]
        if let url = components.url { return url }
      }
    }
    return RCTBundleURLProvider.sharedSettings().jsBundleURL(forBundleRoot: "index")`;

swift = swift.replace(defaultLine, replacement.trimStart());
fs.writeFileSync(appDelegate, swift);

const appDir = path.dirname(appDelegate);
const settingsDir = path.join(appDir, 'Settings.bundle');
fs.mkdirSync(settingsDir, { recursive: true });
const settingsPlist = `<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>PreferenceSpecifiers</key>
  <array>
    <dict>
      <key>Type</key><string>PSGroupSpecifier</string>
      <key>Title</key><string>GitHub Metro / Fast Refresh</string>
      <key>FooterText</key><string>Run the GitHub “Metro hot reload” workflow, copy its https://…trycloudflare.com address, paste it below, then force-close and reopen Auto Sale Umar.</string>
    </dict>
    <dict>
      <key>Type</key><string>PSTextFieldSpecifier</string>
      <key>Title</key><string>Metro tunnel URL</string>
      <key>Key</key><string>metro_url</string>
      <key>DefaultValue</key><string></string>
      <key>IsSecure</key><false/>
      <key>KeyboardType</key><string>URL</string>
      <key>AutocapitalizationType</key><string>None</string>
      <key>AutocorrectionType</key><string>No</string>
    </dict>
  </array>
  <key>StringsTable</key><string>Root</string>
</dict>
</plist>
`;
fs.writeFileSync(path.join(settingsDir, 'Root.plist'), settingsPlist);

console.log(`Patched AppDelegate: ${appDelegate}`);
console.log(`Created Settings.bundle: ${settingsDir}`);
