const fs = require('fs');
const path = require('path');

const root = process.cwd();
const sourceDir = path.join(root, 'ci', 'github-workflows');
const targetDir = path.join(root, '.github', 'workflows');

if (!fs.existsSync(sourceDir)) {
  console.error('[github-actions-bootstrap] Missing ci/github-workflows');
  process.exit(1);
}

fs.mkdirSync(targetDir, { recursive: true });

const files = fs.readdirSync(sourceDir).filter((name) => name.endsWith('.yml') || name.endsWith('.yaml'));

if (!files.length) {
  console.error('[github-actions-bootstrap] No workflow templates found');
  process.exit(1);
}

for (const name of files) {
  const src = path.join(sourceDir, name);
  const dst = path.join(targetDir, name);
  fs.copyFileSync(src, dst);
  console.log(`[github-actions-bootstrap] installed ${path.relative(root, dst)}`);
}
