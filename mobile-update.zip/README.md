# Auto Sale Umar mobile

Bare React Native iOS application for Auto Sale Umar.

- React Native 0.83.6
- no Expo
- no EAS
- React Navigation native bottom tabs
- `react-native-webview` for the synchronized Auto Sale Umar web experience
- GitHub Actions + GitHub-hosted macOS/Xcode for iOS builds
- plain React Native Metro + HTTPS tunnel for Fast Refresh on the registered iPhone

See `GITHUB_BARE_IOS.md` for the full build, signing and hot-reload workflow.
