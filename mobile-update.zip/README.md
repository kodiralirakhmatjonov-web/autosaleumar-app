# Auto Sale Umar mobile

Bare React Native application. Expo, EAS and React Navigation are not part of the runtime or build pipeline.

CI model:
- GitHub Actions applies `mobile-update.zip`.
- GitHub macOS builds the signed iOS Debug IPA.
- A separate GitHub Actions job runs Metro through a temporary Cloudflare tunnel for Fast Refresh.

The intentionally small runtime dependency surface is React Native + WebView + AsyncStorage.
