import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  createContext,
  type PropsWithChildren,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';
import { useColorScheme } from 'react-native';

export type Language = 'ru' | 'uz';
export type ThemeMode = 'system' | 'light' | 'dark';

const LANGUAGE_KEY = 'asu-mobile-language';
const THEME_KEY = 'asu-mobile-theme';

type SettingsContextValue = {
  ready: boolean;
  language: Language;
  setLanguage: (value: Language) => void;
  themeMode: ThemeMode;
  setThemeMode: (value: ThemeMode) => void;
  resolvedTheme: 'light' | 'dark';
};

const SettingsContext = createContext<SettingsContextValue | null>(null);

export function AppSettingsProvider({ children }: PropsWithChildren) {
  const system = useColorScheme();
  const [ready, setReady] = useState(false);
  const [language, setLanguageState] = useState<Language>('ru');
  const [themeMode, setThemeModeState] = useState<ThemeMode>('system');

  useEffect(() => {
    void (async () => {
      const [savedLanguage, savedTheme] = await Promise.all([
        AsyncStorage.getItem(LANGUAGE_KEY),
        AsyncStorage.getItem(THEME_KEY),
      ]);

      if (savedLanguage === 'ru' || savedLanguage === 'uz') {
        setLanguageState(savedLanguage);
      }
      if (savedTheme === 'system' || savedTheme === 'light' || savedTheme === 'dark') {
        setThemeModeState(savedTheme);
      }
      setReady(true);
    })();
  }, []);

  const setLanguage = useCallback((value: Language) => {
    setLanguageState(value);
    void AsyncStorage.setItem(LANGUAGE_KEY, value);
  }, []);

  const setThemeMode = useCallback((value: ThemeMode) => {
    setThemeModeState(value);
    void AsyncStorage.setItem(THEME_KEY, value);
  }, []);

  const resolvedTheme: 'light' | 'dark' =
    themeMode === 'system' ? (system === 'dark' ? 'dark' : 'light') : themeMode;

  const value = useMemo<SettingsContextValue>(
    () => ({ ready, language, setLanguage, themeMode, setThemeMode, resolvedTheme }),
    [language, ready, resolvedTheme, setLanguage, setThemeMode, themeMode],
  );

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
}

export function useAppSettings() {
  const value = useContext(SettingsContext);
  if (!value) {
    throw new Error('useAppSettings must be used inside AppSettingsProvider');
  }
  return value;
}
