import type { NativeStackScreenProps } from '@react-navigation/native-stack';
import { SiteWebView } from '../components/SiteWebView';
import type { RootStackParamList } from '../navigation';

type Props = NativeStackScreenProps<RootStackParamList, 'WebPage'>;

export function WebPageScreen({ route }: Props) {
  return <SiteWebView path={route.params.path} />;
}
