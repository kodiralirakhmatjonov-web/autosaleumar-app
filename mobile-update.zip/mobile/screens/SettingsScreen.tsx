import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useAppSettings, type ThemeMode } from '../state/AppSettings';

type RowProps = {
  mark: string;
  title: string;
  subtitle: string;
  onPress: () => void;
  colors: Palette;
};

type Palette = {
  background: string;
  text: string;
  muted: string;
  surface: string;
  soft: string;
  line: string;
  selected: string;
  selectedText: string;
};

type SettingsScreenProps = {
  onSelectHome: () => void;
  onOpenPath: (path: string, title: string) => void;
};

function Row({ mark, title, subtitle, onPress, colors }: RowProps) {
  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }: { pressed: boolean }) => [
        styles.row,
        { backgroundColor: colors.surface, borderColor: colors.line },
        pressed && styles.pressed,
      ]}
    >
      <View style={[styles.iconWell, { borderColor: colors.line }]}>
        <Text style={[styles.iconText, { color: colors.text }]}>{mark}</Text>
      </View>
      <View style={styles.rowCopy}>
        <Text style={[styles.rowTitle, { color: colors.text }]}>{title}</Text>
        <Text style={[styles.rowSubtitle, { color: colors.muted }]}>{subtitle}</Text>
      </View>
      <Text style={[styles.chevron, { color: colors.muted }]}>›</Text>
    </Pressable>
  );
}

export function SettingsScreen({ onSelectHome, onOpenPath }: SettingsScreenProps) {
  const { language, setLanguage, themeMode, setThemeMode, resolvedTheme } = useAppSettings();
  const dark = resolvedTheme === 'dark';
  const colors: Palette = {
    background: dark ? '#09090a' : '#f4f4f2',
    text: dark ? '#f5f5f7' : '#111214',
    muted: dark ? '#a1a1a6' : '#7d7d82',
    surface: dark ? 'rgba(28,28,30,.96)' : 'rgba(255,255,255,.94)',
    soft: dark ? 'rgba(44,44,46,.82)' : 'rgba(246,246,244,.96)',
    line: dark ? 'rgba(255,255,255,.10)' : 'rgba(60,60,67,.12)',
    selected: dark ? '#f5f5f7' : '#111214',
    selectedText: dark ? '#111214' : '#ffffff',
  };

  const themeItems: Array<{ value: ThemeMode; label: string }> = [
    { value: 'system', label: 'Система' },
    { value: 'light', label: 'Светлая' },
    { value: 'dark', label: 'Тёмная' },
  ];

  return (
    <ScrollView
      style={{ flex: 1, backgroundColor: colors.background }}
      contentContainerStyle={styles.content}
      showsVerticalScrollIndicator={false}
      contentInsetAdjustmentBehavior="automatic"
    >
      <Text style={[styles.kicker, { color: colors.muted }]}>AUTO SALE UMAR</Text>
      <Text style={[styles.title, { color: colors.text }]}>Настройки</Text>
      <Text style={[styles.lead, { color: colors.muted }]}>Навигация приложения, Control System, язык и оформление.</Text>

      <Text style={[styles.sectionLabel, { color: colors.muted }]}>ИНТЕРФЕЙС</Text>
      <View style={styles.group}>
        <Row mark="A" title="Клиент" subtitle="Главная и каталог автомобилей" onPress={onSelectHome} colors={colors} />
        <Row mark="C" title="Control System" subtitle="Панель управления автомобилями" onPress={() => onOpenPath('/admin/cars/', 'Control System')} colors={colors} />
        <Row mark="S" title="Сотрудники" subtitle="Команда, роли и доступ" onPress={() => onOpenPath('/admin/staff/', 'Сотрудники')} colors={colors} />
      </View>

      <Text style={[styles.sectionLabel, { color: colors.muted }]}>ШОУРУМ И СЕРВИС</Text>
      <View style={styles.group}>
        <Row mark="⌂" title="Шоурум" subtitle="Атмосфера и автомобили в шоуруме" onPress={() => onOpenPath('/showroom/', 'Шоурум')} colors={colors} />
        <Row mark="☎" title="Контакты" subtitle="Связаться с Auto Sale Umar" onPress={() => onOpenPath('/contacts/', 'Контакты')} colors={colors} />
        <Row mark="◷" title="Забронировать визит" subtitle="Выбрать дату и время посещения" onPress={() => onOpenPath('/booking/', 'Визит')} colors={colors} />
        <Row mark="✦" title="Получить рекомендацию" subtitle="Персональный подбор автомобиля" onPress={() => onOpenPath('/request-car/', 'Рекомендация')} colors={colors} />
      </View>

      <Text style={[styles.sectionLabel, { color: colors.muted }]}>ЯЗЫК</Text>
      <View style={[styles.segment, { backgroundColor: colors.soft, borderColor: colors.line }]}>
        {(['ru', 'uz'] as const).map(value => (
          <Pressable
            key={value}
            onPress={() => setLanguage(value)}
            style={[styles.segmentButton, language === value && { backgroundColor: colors.selected }]}
          >
            <Text style={[styles.segmentText, { color: language === value ? colors.selectedText : colors.muted }]}>
              {value === 'ru' ? 'Русский' : 'O‘zbek'}
            </Text>
          </Pressable>
        ))}
      </View>

      <Text style={[styles.sectionLabel, { color: colors.muted }]}>ОФОРМЛЕНИЕ</Text>
      <View style={[styles.segment, { backgroundColor: colors.soft, borderColor: colors.line }]}>
        {themeItems.map(item => (
          <Pressable
            key={item.value}
            onPress={() => setThemeMode(item.value)}
            style={[styles.segmentButton, themeMode === item.value && { backgroundColor: colors.selected }]}
          >
            <Text style={[styles.segmentText, { color: themeMode === item.value ? colors.selectedText : colors.muted }]}>
              {item.label}
            </Text>
          </Pressable>
        ))}
      </View>

      <View style={[styles.note, { backgroundColor: colors.surface, borderColor: colors.line }]}>
        <Text style={[styles.noteMark, { color: colors.muted }]}>i</Text>
        <Text style={[styles.noteText, { color: colors.muted }]}>Приложение работает на bare React Native. Expo и EAS в runtime и build pipeline не используются.</Text>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  content: { paddingHorizontal: 18, paddingTop: 24, paddingBottom: 40 },
  kicker: { fontSize: 9, lineHeight: 12, fontWeight: '700', letterSpacing: 1.55 },
  title: { marginTop: 7, fontSize: 40, lineHeight: 43, fontWeight: '700', letterSpacing: -1.6 },
  lead: { marginTop: 8, maxWidth: 500, fontSize: 13, lineHeight: 19 },
  sectionLabel: { marginTop: 30, marginBottom: 10, marginLeft: 4, fontSize: 9, lineHeight: 12, fontWeight: '700', letterSpacing: 1.35 },
  group: { gap: 8 },
  row: { minHeight: 76, paddingHorizontal: 14, borderWidth: StyleSheet.hairlineWidth, borderRadius: 25, flexDirection: 'row', alignItems: 'center', gap: 12 },
  pressed: { opacity: 0.64 },
  iconWell: { width: 40, height: 40, borderRadius: 20, borderWidth: StyleSheet.hairlineWidth, alignItems: 'center', justifyContent: 'center' },
  iconText: { fontSize: 15, fontWeight: '700' },
  rowCopy: { flex: 1, paddingVertical: 12 },
  rowTitle: { fontSize: 15, fontWeight: '600', letterSpacing: -0.18 },
  rowSubtitle: { marginTop: 3, fontSize: 12, lineHeight: 17 },
  chevron: { fontSize: 25, fontWeight: '300', marginRight: 2 },
  segment: { borderRadius: 24, borderWidth: StyleSheet.hairlineWidth, padding: 4, flexDirection: 'row', gap: 4 },
  segmentButton: { flex: 1, minHeight: 42, paddingHorizontal: 8, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  segmentText: { fontSize: 12.5, lineHeight: 16, fontWeight: '600' },
  note: { marginTop: 28, padding: 16, borderWidth: StyleSheet.hairlineWidth, borderRadius: 24, flexDirection: 'row', alignItems: 'flex-start', gap: 10 },
  noteMark: { width: 18, fontSize: 16, lineHeight: 18, fontWeight: '700', textAlign: 'center' },
  noteText: { flex: 1, fontSize: 12.5, lineHeight: 18 },
});
