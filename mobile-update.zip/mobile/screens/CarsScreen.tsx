import { SiteWebView } from '../components/SiteWebView';

export function CarsScreen() {
  return <SiteWebView path="/cars/" />;
}
