import { SiteWebView } from '../components/SiteWebView';

export function VisitScreen() {
  return <SiteWebView path="/booking/" />;
}
