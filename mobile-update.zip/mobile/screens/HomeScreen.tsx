import { SiteWebView } from '../components/SiteWebView';

export function HomeScreen() {
  return <SiteWebView path="/" />;
}
