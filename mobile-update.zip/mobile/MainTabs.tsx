import { Platform } from 'react-native';
import { createNativeBottomTabNavigator } from '@react-navigation/bottom-tabs/unstable';
import { CarsScreen } from './screens/CarsScreen';
import { HomeScreen } from './screens/HomeScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { VisitScreen } from './screens/VisitScreen';
import type { MainTabParamList } from './navigation';

const Tab = createNativeBottomTabNavigator<MainTabParamList>();

function sfSymbol(defaultName: string, selectedName: string) {
  if (Platform.OS !== 'ios') return undefined;
  return ({ focused }: { focused: boolean }) => ({
    type: 'sfSymbol' as const,
    name: focused ? selectedName : defaultName,
  });
}

export function MainTabs() {
  return (
    <Tab.Navigator>
      <Tab.Screen
        name="Home"
        component={HomeScreen}
        options={{ title: 'Главная', tabBarIcon: sfSymbol('house', 'house.fill') }}
      />
      <Tab.Screen
        name="Cars"
        component={CarsScreen}
        options={{ title: 'Автомобили', tabBarIcon: sfSymbol('car', 'car.fill') }}
      />
      <Tab.Screen
        name="Visit"
        component={VisitScreen}
        options={{ title: 'Визит', tabBarIcon: sfSymbol('calendar', 'calendar') }}
      />
      <Tab.Screen
        name="Settings"
        component={SettingsScreen}
        options={{ title: 'Настройки', tabBarIcon: sfSymbol('gearshape', 'gearshape.fill') }}
      />
    </Tab.Navigator>
  );
}
