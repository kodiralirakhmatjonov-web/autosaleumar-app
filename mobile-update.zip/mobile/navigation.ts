export type RootStackParamList = {
  Main: undefined;
  WebPage: {
    path: string;
    title?: string;
  };
};

export type MainTabParamList = {
  Home: undefined;
  Cars: undefined;
  Visit: undefined;
  Settings: undefined;
};
