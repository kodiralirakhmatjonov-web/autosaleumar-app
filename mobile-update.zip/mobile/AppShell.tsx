import { useCallback, useState } from 'react';
import {
  Platform,
  Pressable,
  SafeAreaView,
  StatusBar,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { CarsScreen } from './screens/CarsScreen';
import { HomeScreen } from './screens/HomeScreen';
import { SettingsScreen } from './screens/SettingsScreen';
import { VisitScreen } from './screens/VisitScreen';
import { SiteWebView } from './components/SiteWebView';
import { useAppSettings } from './state/AppSettings';

type TabKey = 'home' | 'cars' | 'visit' | 'settings';
type OverlayPage = { path: string; title: string } | null;

type TabButtonProps = {
  active: boolean;
  label: string;
  symbol: string;
  onPress: () => void;
};

function TabButton({ active, label, symbol, onPress }: TabButtonProps) {
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: active }}
      onPress={onPress}
      style={({ pressed }: { pressed: boolean }) => [styles.tabButton, pressed && styles.pressed]}
    >
      <Text style={[styles.tabSymbol, active && styles.tabSymbolActive]}>{symbol}</Text>
      <Text style={[styles.tabLabel, active && styles.tabLabelActive]} numberOfLines={1}>
        {label}
      </Text>
    </Pressable>
  );
}

function BottomBar({ active, onSelect }: { active: TabKey; onSelect: (tab: TabKey) => void }) {
  return (
    <SafeAreaView style={styles.bottomSafeArea}>
      <View style={styles.bottomBar}>
        <TabButton active={active === 'home'} label="Главная" symbol="⌂" onPress={() => onSelect('home')} />
        <TabButton active={active === 'cars'} label="Автомобили" symbol="◇" onPress={() => onSelect('cars')} />
        <TabButton active={active === 'visit'} label="Визит" symbol="◷" onPress={() => onSelect('visit')} />
        <TabButton active={active === 'settings'} label="Настройки" symbol="⚙︎" onPress={() => onSelect('settings')} />
      </View>
    </SafeAreaView>
  );
}

function Overlay({ page, onClose }: { page: NonNullable<OverlayPage>; onClose: () => void }) {
  return (
    <View style={styles.overlay}>
      <SafeAreaView style={styles.overlayHeaderSafeArea}>
        <View style={styles.overlayHeader}>
          <Pressable onPress={onClose} hitSlop={12} style={({ pressed }: { pressed: boolean }) => [styles.backButton, pressed && styles.pressed]}>
            <Text style={styles.backText}>‹ Назад</Text>
          </Pressable>
          <Text style={styles.overlayTitle} numberOfLines={1}>{page.title}</Text>
          <View style={styles.headerSpacer} />
        </View>
      </SafeAreaView>
      <View style={styles.overlayBody}>
        <SiteWebView path={page.path} />
      </View>
    </View>
  );
}

export function AppShell() {
  const { ready, resolvedTheme } = useAppSettings();
  const [tab, setTab] = useState<TabKey>('home');
  const [overlay, setOverlay] = useState<OverlayPage>(null);

  const openPage = useCallback((path: string, title: string) => {
    setOverlay({ path, title });
  }, []);

  if (!ready) {
    return <View style={[styles.loading, resolvedTheme === 'dark' && styles.loadingDark]} />;
  }

  const screen = (() => {
    switch (tab) {
      case 'cars':
        return <CarsScreen />;
      case 'visit':
        return <VisitScreen />;
      case 'settings':
        return (
          <SettingsScreen
            onSelectHome={() => setTab('home')}
            onOpenPath={openPage}
          />
        );
      case 'home':
      default:
        return <HomeScreen />;
    }
  })();

  return (
    <View style={[styles.root, resolvedTheme === 'dark' && styles.rootDark]}>
      <StatusBar barStyle={resolvedTheme === 'dark' ? 'light-content' : 'dark-content'} />
      <View style={styles.screen}>{screen}</View>
      <BottomBar active={tab} onSelect={setTab} />
      {overlay ? <Overlay page={overlay} onClose={() => setOverlay(null)} /> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1, backgroundColor: '#f4f4f2' },
  rootDark: { backgroundColor: '#09090a' },
  loading: { flex: 1, backgroundColor: '#f4f4f2' },
  loadingDark: { backgroundColor: '#09090a' },
  screen: { flex: 1 },
  bottomSafeArea: {
    backgroundColor: Platform.OS === 'ios' ? 'rgba(247,247,247,0.96)' : '#f7f7f7',
    borderTopWidth: StyleSheet.hairlineWidth,
    borderTopColor: 'rgba(60,60,67,0.18)',
  },
  bottomBar: {
    height: 58,
    flexDirection: 'row',
    alignItems: 'stretch',
    justifyContent: 'space-around',
  },
  tabButton: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 2,
    paddingHorizontal: 4,
  },
  tabSymbol: { fontSize: 20, lineHeight: 22, color: '#8e8e93', fontWeight: '500' },
  tabSymbolActive: { color: '#111214' },
  tabLabel: { fontSize: 10, lineHeight: 12, color: '#8e8e93', fontWeight: '500' },
  tabLabelActive: { color: '#111214', fontWeight: '700' },
  pressed: { opacity: 0.55 },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: '#ffffff',
    zIndex: 50,
  },
  overlayHeaderSafeArea: {
    backgroundColor: 'rgba(255,255,255,0.97)',
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: 'rgba(60,60,67,0.18)',
  },
  overlayHeader: {
    height: 48,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 14,
  },
  backButton: { width: 86, height: 40, justifyContent: 'center' },
  backText: { color: '#111214', fontSize: 16, fontWeight: '600' },
  overlayTitle: { flex: 1, textAlign: 'center', color: '#111214', fontSize: 15, fontWeight: '700' },
  headerSpacer: { width: 86 },
  overlayBody: { flex: 1 },
});
