import { useMemo } from 'react';
import { StyleSheet, View } from 'react-native';
import WebView from 'react-native-webview';
import { useAppSettings } from '../state/AppSettings';

const SITE_ORIGIN = 'https://autosaleumar.com';

function normalizePath(path: string) {
  if (!path) return '/';
  return path.startsWith('/') ? path : `/${path}`;
}

function withAppMode(path: string, language: string, theme: string) {
  const normalized = normalizePath(path);
  const hashIndex = normalized.indexOf('#');
  const basePath = hashIndex >= 0 ? normalized.slice(0, hashIndex) : normalized;
  const hash = hashIndex >= 0 ? normalized.slice(hashIndex) : '';
  const separator = basePath.includes('?') ? '&' : '?';

  return `${basePath}${separator}asu_app=1&asu_lang=${encodeURIComponent(language)}&asu_theme=${encodeURIComponent(theme)}${hash}`;
}

export function SiteWebView({ path }: { path: string }) {
  const { language, themeMode, resolvedTheme } = useAppSettings();
  const uri = useMemo(
    () => `${SITE_ORIGIN}${withAppMode(path, language, themeMode)}`,
    [language, path, themeMode],
  );

  return (
    <View style={[styles.container, { backgroundColor: resolvedTheme === 'dark' ? '#09090a' : '#f4f4f2' }]}>
      <WebView
        key={uri}
        source={{ uri }}
        style={styles.webview}
        originWhitelist={['*']}
        javaScriptEnabled
        domStorageEnabled
        sharedCookiesEnabled
        thirdPartyCookiesEnabled
        allowsInlineMediaPlayback
        mediaPlaybackRequiresUserAction={false}
        setSupportMultipleWindows={false}
        allowsBackForwardNavigationGestures
        contentInsetAdjustmentBehavior="never"
        automaticallyAdjustContentInsets={false}
        pullToRefreshEnabled
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  webview: { flex: 1, backgroundColor: 'transparent' },
});
