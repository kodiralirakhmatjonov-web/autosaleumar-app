# Auto Sale Umar — GitHub iOS build migration

This repository keeps Expo SDK / Expo Router because the application currently uses them.
The migration removes EAS Build / EAS Update from CI. Native compilation is done on
GitHub-hosted macOS + Xcode.

Installed workflows:

1. `1 - Generate Apple signing CSR`
   Generates a CSR plus an AES-encrypted private key. The artifact is retained for one day.

2. `2A - Build iPhone Debug IPA`
   Builds a real Debug configuration signed with an iOS App Development profile.
   This binary requires a Metro server to load JavaScript.

3. `2B - Build TestFlight Development Client`
   Builds a Release archive with `expo-dev-client` included, exports an App Store Connect IPA,
   and uploads it with Apple's `altool`. This is the practical no-Mac installation path.

4. `3 - Metro Hot Reload Session`
   Runs Metro on a GitHub Ubuntu runner through a tunnel for up to 5h50m. It polls `main`
   every 15 seconds so committed JS/TS changes can reach the running development client.

Important Apple limitation:
A raw registered-device `.ipa` exported for debugging is officially installed using Xcode
or Apple Configurator. If there is no Mac at all, use the TestFlight development-client
workflow for installation and the Metro workflow for Fast Refresh.

The existing `Apply mobile-update.zip` workflow is replaced with a GitHub-only version:
no EAS login, no EAS project linking, and no EAS Update publication.
