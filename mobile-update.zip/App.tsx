import { StatusBar, useColorScheme } from 'react-native';
import { NavigationContainer, DarkTheme, DefaultTheme } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { AppSettingsProvider, useAppSettings } from './mobile/state/AppSettings';
import { MainTabs } from './mobile/MainTabs';
import { WebPageScreen } from './mobile/screens/WebPageScreen';
import type { RootStackParamList } from './mobile/navigation';

const RootStack = createNativeStackNavigator<RootStackParamList>();

function NavigationRoot() {
  const { ready, resolvedTheme } = useAppSettings();
  const systemTheme = useColorScheme();
  const dark = ready ? resolvedTheme === 'dark' : systemTheme === 'dark';

  if (!ready) {
    return null;
  }

  return (
    <>
      <StatusBar barStyle={dark ? 'light-content' : 'dark-content'} />
      <NavigationContainer theme={dark ? DarkTheme : DefaultTheme}>
        <RootStack.Navigator screenOptions={{ headerShown: false }}>
          <RootStack.Screen name="Main" component={MainTabs} />
          <RootStack.Screen name="WebPage" component={WebPageScreen} />
        </RootStack.Navigator>
      </NavigationContainer>
    </>
  );
}

export default function App() {
  return (
    <SafeAreaProvider>
      <AppSettingsProvider>
        <NavigationRoot />
      </AppSettingsProvider>
    </SafeAreaProvider>
  );
}
