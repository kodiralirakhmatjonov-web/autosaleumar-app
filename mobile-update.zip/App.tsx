import { AppShell } from './mobile/AppShell';
import { AppSettingsProvider } from './mobile/state/AppSettings';

export default function App() {
  return (
    <AppSettingsProvider>
      <AppShell />
    </AppSettingsProvider>
  );
}
